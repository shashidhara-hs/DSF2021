//
//  ViewController.swift
//  ColorPicker
//
//  Created by Shashidhara H S on 25/10/21.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var colorSwatch: UIView!
    
    @IBOutlet weak var redSwitch: UISwitch!
    @IBOutlet weak var greenSwitch: UISwitch!
        @IBOutlet weak var blueSwitch: UISwitch!
    
    @IBOutlet weak var redSlider: UISlider!
    @IBOutlet weak var greenSlider: UISlider!
    @IBOutlet weak var blueSlider: UISlider!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        colorSwatch.layer.borderWidth = 5
        colorSwatch.layer.cornerRadius = 20
        colorSwatch.layer.borderColor = UIColor.black.cgColor
        updateColor()
    }

    @IBAction func switchChanged(_ sender: UISwitch) {
        updateColor()
        
    }
    
    func updateColor() {
        var red:CGFloat = 0
        var green:CGFloat = 0
        var blue:CGFloat = 0
        
        if redSwitch.isOn {
            red = CGFloat(redSlider.value)
        }
        if greenSwitch.isOn {
            green = CGFloat(greenSlider.value)
        }
        if blueSwitch.isOn {
            blue = CGFloat(blueSlider.value)
        }
        
        let color = UIColor(red: red, green: green, blue: blue, alpha: 1)
        colorSwatch.backgroundColor = color
    }
    
    @IBAction func sliderChanger(_ sender: UISlider) {
        updateColor()
    }
    
    
}

